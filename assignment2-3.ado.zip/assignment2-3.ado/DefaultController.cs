﻿using assbusinfo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace assbusinfo.Controllers
{
    public class DefaultController : Controller
    {
        BusInfoEntities1 db = new BusInfoEntities1();
        public ActionResult Index()
        {

           return View( from b in db.tblBusInfoes
                        where b.BoardingPoint =="MUM"
                        select b);
        }
    }
}