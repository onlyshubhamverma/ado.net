﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using _2ado.Models;

namespace _2ado.Controllers
{
    public class DefaultController : Controller
    {
        // GET: Default
        FootBallContext context=new FootBallContext();  
        public ActionResult Index()
        {
            context.FootballTable.ToList();
            return View();
        }
        [HttpPost]
        public void Create(string teamname1, string teamname2, string status, string winteam, int points)
        {
            SqlConnection con = new SqlConnection("data source = kalyani; database = footleague; integrated security=SSPI");
            SqlCommand cmd = con.CreateCommand();
            con.Open();
            cmd.CommandText = "Execute storedfoot @TeamName1,@TeamName2,@Status,@WinningTeam,@Points";
            cmd.Parameters.Add("@TeamName1", SqlDbType.VarChar, 50).Value = teamname1;
            cmd.Parameters.Add("@TeamName2", SqlDbType.VarChar, 50).Value = teamname2;
            cmd.Parameters.Add("@Status", SqlDbType.VarChar, 50).Value = status;
            cmd.Parameters.Add("@WinningTeam", SqlDbType.VarChar, 50).Value = winteam;
            cmd.Parameters.Add("@Points", SqlDbType.Int, 4).Value = points;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
    }
}