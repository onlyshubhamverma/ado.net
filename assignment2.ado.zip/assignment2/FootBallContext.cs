﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Entity;



namespace _2ado.Models
{
    public class FootBallContext :DbContext
    {
        public FootBallContext(): base("name = FootballConnection")
               
            {

            }
         public DbSet<Foootball> FootballTable { get; set; }

      
    }
}