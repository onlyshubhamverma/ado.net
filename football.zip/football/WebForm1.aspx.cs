﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace WebApplication3
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string cs = "data source=kalyani\\SQLEXPRESS; database= assignment1;integrated security=SSPI";
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("select WinningTeam from footballteams where Status = 'Win';select * from footBallteams where TeamName1 ='Japan' or TeamName2='Japan' ", con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                GridView1.DataSource = dr;

                GridView1.DataBind();

                while (dr.NextResult())
                {
                    GridView2.DataSource=dr;
                    GridView2.DataBind();

                }
                    }

            

        }
    }

    
}